# core/panel_solver.py
import numpy as np
from typing import List, Tuple
import math

def panel_method_cl(x: List[float], y: List[float], alpha_deg: float) -> Tuple[float, dict]:
    """
    Very simple vortex-panel solver (constant-strength panels) for inviscid flow.
    Returns Cl (2D, per unit span). Also returns dictionary with Cp distribution arrays.
    """
    # convert to arrays
    xc = np.array(x); yc = np.array(y)
    N = len(xc)-1
    # panel control points and lengths
    xj = (xc[:-1] + xc[1:])/2.0
    yj = (yc[:-1] + yc[1:])/2.0
    sj = np.sqrt((xc[1:]-xc[:-1])**2 + (yc[1:]-yc[:-1])**2)
    # panel angles
    theta = np.arctan2(yc[1:]-yc[:-1], xc[1:]-xc[:-1])
    # Build influence matrix A for vortex panels
    A = np.zeros((N, N))
    RHS = np.zeros(N)
    alpha = np.deg2rad(alpha_deg)
    # free-stream normal velocity at control points
    for i in range(N):
        for j in range(N):
            if i == j:
                # self term
                A[i,j] = 0.5
            else:
                # influence of vortex on control point normal
                dx1 = xc[j] - xj[i]
                dy1 = yc[j] - yj[i]
                dx2 = xc[j+1] - xj[i]
                dy2 = yc[j+1] - yj[i]
                def phi(dx,dy):
                    return math.atan2(dy,dx)
                # induced tangential difference / (2*pi)
                A[i,j] = (phi(dx2,dy2) - phi(dx1,dy1)) / (2*math.pi)
        # right-hand side: -U_infty * normal component
        nx = math.sin(theta[i])  # normal pointing outward approximated
        ny = -math.cos(theta[i])
        RHS[i] = - (math.cos(alpha)*nx + math.sin(alpha)*ny)
    # Kutta condition: circulation continuity: sum(gamma_j * (something)) = 0
    # For constant-vortex panels, apply integral condition by replacing last equation
    # Build augmented system
    A_aug = np.zeros((N+1, N+1))
    A_aug[:N,:N] = A
    A_aug[:N,-1] = 0.0
    A_aug[-1,:N] = 0.0
    # enforce gamma_0 + gamma_{N-1} = 0 (simple Kutta)
    A_aug[-1,0] = 1.0
    A_aug[-1,N-1] = 1.0
    RHS_aug = np.zeros(N+1)
    RHS_aug[:N] = RHS
    # solve linear system
    try:
        sol = np.linalg.solve(A_aug, RHS_aug)
    except np.linalg.LinAlgError:
        raise RuntimeError("Panel method linear system singular")
    gamma = sol[:N]
    # compute circulation (sum gamma * panel length)
    Gamma = np.sum(gamma * sj)
    # Lift per unit span: L' = rho * U_inf * Gamma ; for non-dimensional Cl2D = 2*Gamma (with U=1, rho=1)
    # For unit free-stream U=1, Cl (2D) approximated as 2*Gamma
    Cl2d = 2.0 * Gamma
    # compute approximate Cp on panels (simple formula)
    # tangential velocity approx: Vt = U_inf * sin(alpha - theta) + sum influences (here omitted for simplicity)
    # we'll estimate Cp ~ 1 - (Vt)^2 ; use only freestream component for rough Cp
    Vt = np.array([math.cos(alpha - th) for th in theta])
    Cp = 1.0 - Vt**2
    return Cl2d, {"gamma": gamma.tolist(), "Cp": Cp.tolist(), "x_panel": xj.tolist(), "y_panel": yj.tolist(), "theta": theta.tolist()}
