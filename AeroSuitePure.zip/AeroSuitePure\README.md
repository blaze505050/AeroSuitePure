# AeroSuitePure — Airfoil Optimization 
Features:
- Pure Python 2D panel method solver 
- Tkinter GUI for runs, sweeps, and small GA optimization
- NACA airfoil generator
- CSV export and plot saving
- Minimal dependencies

Run:
1. Install deps: `pip3 install numpy matplotlib`
2. From project root: `python3 gui/gui_tk.py`
